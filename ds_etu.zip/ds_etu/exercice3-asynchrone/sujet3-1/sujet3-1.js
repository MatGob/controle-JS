/* Nom : GOBIN
Prenom : Matthieu 
Groupe : 2
*/
document.addEventListener('DOMContentLoaded',function(){
    const display = document.getElementById('display');
    const button = document.getElementById('boutton'); // ajouter dans l'html
    const calories = document.getElementById('search');

    var callBackGetSuccess = function (data) {
        
        var html = "";
        data.forEach(element => { // Pour chaque resultat
            html = html + element.image + '</br>';
        }); 
        display.innerHTML = html; // On les ajoutes
    }
    
    button.addEventListener('click',function() {
        const APIKey = "55075144f1ed42b5b8aecac89ce6e143"; //cle api
        var calorie = calories.value ; // recupere les calories
        var url = "https://api.spoonacular.com/recipes/findByNutrients?minCalories="+calorie+"&apiKey="+APIKey;
        
        $.get(url,callBackGetSuccess).done(function(){ // Quand on  a le resultat
            
        })
        .fail(function(){
            alert("Petit problème");
        })
        .always(function(){
        
        });
    });
});