/* Nom : GOBIN
Prenom : Matthieu
Groupe : Grp 2
*/
window.addEventListener("load",()=>{
let data = [];
for(let i = 0;  i<5; i++)
    data.push({
        id: i,
        src:"cat"+i+".jpg",
        title: "Chat "+i
    })
for(let i = 0;  i<5; i++)
    data.push({
        id: i+5,
        src:"nightlife"+i+".jpg",
        title: "Nuit "+i
    })

const display = document.querySelector('#display');
var html ="";

data.forEach(element => { // Pour chaque image
    
    let div = document.createElement('div');
    div.setAttribute("class","col m2")
    div.innerHTML =
    ` 
        <div class="card">
            <div class="card-image">
                <img src="../../assets/images/${element.src}">
                <span class="card-title">${element.title}</span>
            </div>
            <div class="card-action">
                <a href="#" onclick="removeSaufElle('${element.title}')" >This is a link</a>
            </div>
        </div>
    ` // On met le code html dedans
    ;
    display.appendChild(div);

});
});

function removeSaufElle (title) {
    // passe que le nom et pas l'image car ne sait pas comment faire pour 2 parametres
    let div = document.createElement('div');
    div.setAttribute("class","col m2")
    div.innerHTML =
    ` 
        <div class="card">
            <div class="card-image">
                <img src="../../assets/images/>
                <span class="card-title">${title}</span>
            </div>
            <div class="card-action">
                <a href="#" >This is a link</a>
            </div>
        </div>
    `
    ;
    display.innerHTML=""; // supprime tout et met la nouvelle
    display.appendChild(div);
}